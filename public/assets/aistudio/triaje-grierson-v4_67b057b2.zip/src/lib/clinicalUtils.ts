import { PatientData, VitalSigns, TriageLevel, FINDINGS } from '../types';

/**
 * Valores de referencia de FR y FC por grupo de edad, en bandas de desvío estándar (DS).
 * Fuente: herramienta "o3age v1 - Equipo Docente" (tablas de referencia de FR y FC).
 * Se usan solo para el cálculo: no se muestran en pantalla.
 *   Más allá de ±2 DS      -> Nivel I
 *   Dentro de la banda ±2 DS -> Nivel II
 *   Dentro de la banda ±1 DS -> Nivel III
 *   Normal                  -> no modifica el nivel
 */
/** SpO2 por debajo de este valor (%) fuerza al menos Nivel II. */
export const SPO2_UMBRAL_NIVEL_II = 92;

type Banda = [number, number];
interface RangoDS { m2: Banda; m1: Banda; normal: Banda; p1: Banda; p2: Banda }

const TABLA_FR: { hastaMeses: number; r: RangoDS }[] = [
  { hastaMeses: 3,        r: { m2: [10, 20], m1: [20, 30], normal: [30, 60], p1: [60, 70], p2: [70, 80] } },
  { hastaMeses: 6,        r: { m2: [10, 20], m1: [20, 30], normal: [30, 60], p1: [60, 70], p2: [70, 80] } },
  { hastaMeses: 12,       r: { m2: [10, 17], m1: [17, 25], normal: [25, 45], p1: [45, 55], p2: [55, 60] } },
  { hastaMeses: 36,       r: { m2: [10, 15], m1: [15, 20], normal: [20, 30], p1: [30, 35], p2: [35, 40] } },
  { hastaMeses: 72,       r: { m2: [8, 12],  m1: [12, 16], normal: [16, 24], p1: [24, 28], p2: [28, 32] } },
  { hastaMeses: 120,      r: { m2: [8, 10],  m1: [10, 14], normal: [14, 20], p1: [20, 24], p2: [24, 26] } },
  { hastaMeses: Infinity, r: { m2: [8, 10],  m1: [10, 14], normal: [14, 20], p1: [20, 24], p2: [24, 26] } },
];

const TABLA_FC: { hastaMeses: number; r: RangoDS }[] = [
  { hastaMeses: 3,        r: { m2: [40, 65], m1: [65, 90], normal: [90, 180], p1: [180, 205], p2: [205, 230] } },
  { hastaMeses: 6,        r: { m2: [40, 63], m1: [63, 80], normal: [80, 160], p1: [160, 180], p2: [180, 210] } },
  { hastaMeses: 12,       r: { m2: [40, 60], m1: [60, 80], normal: [80, 140], p1: [140, 160], p2: [160, 180] } },
  { hastaMeses: 36,       r: { m2: [40, 58], m1: [58, 75], normal: [75, 130], p1: [130, 145], p2: [145, 165] } },
  { hastaMeses: 72,       r: { m2: [40, 55], m1: [55, 70], normal: [70, 110], p1: [110, 125], p2: [125, 140] } },
  { hastaMeses: 120,      r: { m2: [30, 45], m1: [45, 60], normal: [60, 90],  p1: [90, 105],  p2: [105, 120] } },
  { hastaMeses: Infinity, r: { m2: [30, 45], m1: [45, 60], normal: [60, 90],  p1: [90, 105],  p2: [105, 120] } },
];

/** Grupo etario: 0-3 m, 3-6 m, 6-12 m, 1-3 a, 3-6 a, 6-10 a, >10 a (límite inferior incluido en el grupo siguiente). */
export const getVitalsRange = (ageMonths: number, type: 'FR' | 'FC'): RangoDS => {
  const tabla = type === 'FR' ? TABLA_FR : TABLA_FC;
  return (tabla.find(g => ageMonths < g.hastaMeses) || tabla[tabla.length - 1]).r;
};

export type DsKey =
  | 'menor_menos_2_ds_fuera_tabla' | 'menos_2_ds' | 'menos_1_ds' | 'normal'
  | 'mas_1_ds' | 'mas_2_ds' | 'mayor_mas_2_ds_fuera_tabla' | 'no_calculado';

/** Clasifica un valor en su banda DS. En un límite compartido se asigna la banda menos grave. */
export const getVitalsDsKey = (val: number | undefined, ageMonths: number | undefined, type: 'FR' | 'FC'): DsKey => {
  if (val === undefined || val === null || isNaN(val) || val <= 0) return 'no_calculado';
  const r = getVitalsRange(ageMonths ?? 216, type);
  if (val >= r.normal[0] && val <= r.normal[1]) return 'normal';
  if (val > r.normal[1]) {
    if (val <= r.p1[1]) return 'mas_1_ds';
    if (val <= r.p2[1]) return 'mas_2_ds';
    return 'mayor_mas_2_ds_fuera_tabla';
  }
  if (val >= r.m1[0]) return 'menos_1_ds';
  if (val >= r.m2[0]) return 'menos_2_ds';
  return 'menor_menos_2_ds_fuera_tabla';
};

/** Nivel CTAS que impone una banda DS de FR o FC (5 = no modifica). */
export const nivelPorDs = (k: DsKey): number =>
  k === 'mayor_mas_2_ds_fuera_tabla' || k === 'menor_menos_2_ds_fuera_tabla' ? 1
  : k === 'mas_2_ds' || k === 'menos_2_ds' ? 2
  : k === 'mas_1_ds' || k === 'menos_1_ds' ? 3
  : 5;

/** Se conserva por compatibilidad: devuelve la clave DS para guardar en la base (no se muestra). */
export const getVitalsDSLabel = (
  val: number | undefined,
  ageMonths: number | undefined,
  type: 'FR' | 'FC'
): { label: string; colorClass: string; key: string } => {
  const key = getVitalsDsKey(val, ageMonths, type);
  return { label: '', colorClass: '', key };
};

export const getTepLadosAlterados = (data: Partial<PatientData>) => {
  if (!data.tepStates) return 0;
  const { apariencia, respiracion, circulacion } = data.tepStates;
  let count = 0;
  if (apariencia === 'alterado') count++;
  if (respiracion === 'alterado') count++;
  if (circulacion === 'alterado') count++;
  return count;
};

export const getTepLadosList = (data: Partial<PatientData>) => {
  if (!data.tepStates) return [];
  const list = [];
  if (data.tepStates.apariencia === 'alterado') list.push('Apariencia');
  if (data.tepStates.respiracion === 'alterado') list.push('Respiración');
  if (data.tepStates.circulacion === 'alterado') list.push('Circulación');
  return list;
};

export const getVitalsRequirementsByLevel = (levelStr: TriageLevel) => {
  const levelNum = levelStr === 'I' ? 1 : levelStr === 'II' ? 2 : levelStr === 'III' ? 3 : levelStr === 'IV' ? 4 : 5;

  if ([1, 2, 3].includes(levelNum)) {
    return {
      heartRate: true,
      respiratoryRate: true,
      systolicBP: false,        // TA no obligatoria (pedido del equipo de Emergencias)
      diastolicBP: false,
      oxygenSaturation: false,  // SpO2 no obligatoria (pedido del equipo de Emergencias)
      temperature: true,
      glucose: false,
    };
  }
  return {
    heartRate: true,
    respiratoryRate: true,
    systolicBP: false,
    diastolicBP: false,
    oxygenSaturation: false,
    temperature: false,
    glucose: false,
  };
};

export const calculateTriage = (
  data: Partial<PatientData>,
  isManualBypassActive: boolean = false
): { level: TriageLevel; priority: string; wait: string; destination: string } => {
  const v = data.vitals || {
    heartRate: undefined,
    respiratoryRate: undefined,
    systolicBP: undefined,
    diastolicBP: undefined,
    oxygenSaturation: undefined,
    temperature: undefined,
    glucose: undefined,
    avpu: 'A',
  };
  const ageMonths = data.age !== undefined ? data.age * (data.ageUnit === 'años' ? 12 : 1) : undefined;

  let suggestedLevelValue = 5;

  // --- 1. Bypass Crítico (Clinically Explicit or Manual Bypass) ---
  if (isManualBypassActive || data.estadoOperativo === 'preliminar_critico') {
    suggestedLevelValue = 1;
  }

  // --- 2. Triángulo de Evaluación Pediátrica (TEP) ---
  // 3 lados afectados -> Nivel I (Rojo)
  // 2 lados afectados -> Nivel II (Naranja)
  // 1 lado afectado -> Nivel III (Amarillo)
  if (data.type === 'pediatric' && data.tepStates) {
    const lados = getTepLadosAlterados(data);
    if (lados === 3) {
      suggestedLevelValue = Math.min(suggestedLevelValue, 1);
    } else if (lados === 2) {
      suggestedLevelValue = Math.min(suggestedLevelValue, 2);
    } else if (lados === 1) {
      suggestedLevelValue = Math.min(suggestedLevelValue, 3);
    }
  }

  // --- 3. AVPU Neurological Modifier ---
  if (v.avpu !== undefined) {
    if (v.avpu === 'U') {
      suggestedLevelValue = Math.min(suggestedLevelValue, 1);
    } else if (v.avpu === 'P') {
      suggestedLevelValue = Math.min(suggestedLevelValue, 2);
    } else if (v.avpu === 'V') {
      suggestedLevelValue = Math.min(suggestedLevelValue, 3);
    }
  }

  // --- 4. Constantes fisiológicas: solo FR y FC modifican el nivel (bandas DS por edad) ---
  // TA, temperatura y glucemia no asignan nivel automáticamente (SpO2: ver umbral abajo): se informan como
  // alerta para orientar la elección del problema principal (criterio de la herramienta o3age).
  const effectiveAge = ageMonths !== undefined ? ageMonths : 216;
  if (v.respiratoryRate !== undefined) {
    suggestedLevelValue = Math.min(suggestedLevelValue, nivelPorDs(getVitalsDsKey(v.respiratoryRate, effectiveAge, 'FR')));
  }
  if (v.heartRate !== undefined) {
    suggestedLevelValue = Math.min(suggestedLevelValue, nivelPorDs(getVitalsDsKey(v.heartRate, effectiveAge, 'FC')));
  }

  // SpO2 baja: fuerza al menos Nivel II (criterio provisorio definido por la División, nov-2026).
  if (v.oxygenSaturation !== undefined && v.oxygenSaturation !== null && !isNaN(v.oxygenSaturation as number) && (v.oxygenSaturation as number) < SPO2_UMBRAL_NIVEL_II) {
    suggestedLevelValue = Math.min(suggestedLevelValue, 2);
  }

  // --- 5. Clinical Findings / Discriminators Modifiers ---
  if (data.findings?.some(f => FINDINGS.LEVEL_I.includes(f))) {
    suggestedLevelValue = Math.min(suggestedLevelValue, 1);
  }
  if (data.findings?.some(f => FINDINGS.LEVEL_II.includes(f))) {
    suggestedLevelValue = Math.min(suggestedLevelValue, 2);
  }
  if (data.findings?.some(f => FINDINGS.LEVEL_III.includes(f))) {
    suggestedLevelValue = Math.min(suggestedLevelValue, 3);
  }
  if (data.findings?.some(f => FINDINGS.LEVEL_IV.includes(f))) {
    suggestedLevelValue = Math.min(suggestedLevelValue, 4);
  }
  if (data.findings?.some(f => FINDINGS.LEVEL_V.includes(f))) {
    suggestedLevelValue = Math.min(suggestedLevelValue, 5);
  }

  // Map level number to Roman numeral and label
  const levelMap: Record<number, { level: TriageLevel; priority: string; wait: string; destination: string }> = {
    1: { level: 'I', priority: 'Nivel I - Resucitación', wait: 'Inmediata (0 min)', destination: 'Shock Room' },
    2: { level: 'II', priority: 'Nivel II - Emergencia', wait: '≤ 15 min', destination: 'Box de Emergencias' },
    3: { level: 'III', priority: 'Nivel III - Urgente', wait: '≤ 30 min', destination: 'Consultorio de Urgencias' },
    4: { level: 'IV', priority: 'Nivel IV - Menos Urgente', wait: '≤ 60 min', destination: 'Consultorio General' },
    5: { level: 'V', priority: 'Nivel V - No Urgente', wait: '≤ 120 min', destination: 'Consulta Externa / Admisión' },
  };

  return levelMap[suggestedLevelValue] || levelMap[5];
};
